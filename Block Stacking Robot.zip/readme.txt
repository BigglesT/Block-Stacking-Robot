Block Stacking Robot by Abigail Egya-Mensah and Frank Laubach

Common
-assets: block urdf, panda meshes and specs

Haar Classifier
-classifier: Haar classifier generated 
-Blocks: images used to train Haar classifier
-positive-1.py: Generates information about the positive images for creating the classifier
-Info.txt: Description of all positive samples
-negative.txt: Description of all negative code
-text.py: Contains codes that generate positive samples, Creates and trains classifier and tests the classifier.
-training_block_generator.py: generates blocks used for training Haar
-positive_samples.vec: Vec file generated for training classifier

Main Method Implementation
-Powerpoint presentation
-Report
-block_stacking_algorithm: main algorithm that implements methods
